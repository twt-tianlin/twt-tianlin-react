# 天外天 天麟班系统



## 技术栈

React 18  +  React-Router-Dom 6  +  Redux  +  +Ant Design  +  TypeScript



## 项目启动

```shell
git clone https://github.com/twt-tianlin/twt-tianlin-react.git

cd twt-tianlin-react

yarn 

yarn start
```

